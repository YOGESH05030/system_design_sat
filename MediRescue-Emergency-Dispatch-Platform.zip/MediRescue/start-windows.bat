@echo off
echo Installing MediRescue dependencies...
call npm install
if errorlevel 1 exit /b 1
call npm --prefix server install
if errorlevel 1 exit /b 1
echo.
echo Starting MediRescue frontend and backend...
call npm run dev
