import { useEffect, useMemo, useState } from 'react'
import type { FormEvent, Dispatch, SetStateAction } from 'react'
import {
  Activity, Ambulance, Bell, Building2, Check, ChevronDown, CircleHelp, Clock3,
  Command, Gauge, HeartPulse, LayoutDashboard, MapPin, Menu, MessageSquare,
  Network, Plus, Radio, Search, Server, Settings, ShieldCheck, Siren, Truck,
  Users, X, Zap, ArrowUpRight, Database, RefreshCw, Send, Ban, CheckCircle2
} from 'lucide-react'
import {
  Area, AreaChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer,
  Tooltip, XAxis, YAxis, BarChart, Bar
} from 'recharts'

type RequestStatus = 'Pending' | 'Searching' | 'Assigned' | 'En Route' | 'Arrived' | 'Completed' | 'Cancelled'
type Emergency = { id: string; patient: string; type: string; severity: string; city: string; address: string; status: RequestStatus; ambulance: string; time: string }
type Vehicle = { id: string; driver: string; city: string; status: string; type: string; speed: number; lat: number; lng: number; assigned?: string }
type Hospital = { name: string; city: string; beds: number; specialty: string; status: string; distance: string }
const initialRequests: Emergency[] = [
  { id: 'ER-2048', patient: 'Arun Kumar', type: 'Cardiac emergency', severity: 'Critical', city: 'Chennai', address: 'Anna Salai, Chennai', status: 'En Route', ambulance: 'AMB-014', time: '2 min ago' },
  { id: 'ER-2047', patient: 'Priya S.', type: 'Road accident', severity: 'High', city: 'Coimbatore', address: 'Avinashi Road, Coimbatore', status: 'Assigned', ambulance: 'AMB-008', time: '5 min ago' },
  { id: 'ER-2046', patient: 'R. Mahesh', type: 'Medical emergency', severity: 'Medium', city: 'Bengaluru', address: 'Indiranagar, Bengaluru', status: 'Searching', ambulance: 'Not assigned', time: '8 min ago' },
  { id: 'ER-2045', patient: 'Lakshmi R.', type: 'Accident', severity: 'High', city: 'Hyderabad', address: 'Hitech City, Hyderabad', status: 'Pending', ambulance: 'Not assigned', time: '11 min ago' },
  { id: 'ER-2044', patient: 'Karthik V.', type: 'Medical emergency', severity: 'Low', city: 'Chennai', address: 'Velachery, Chennai', status: 'Completed', ambulance: 'AMB-002', time: '18 min ago' },
]
const initialVehicles: Vehicle[] = [
  { id: 'AMB-014', driver: 'R. Suresh', city: 'Chennai', status: 'En Route', type: 'Advanced Life Support', speed: 42, lat: 13.0569, lng: 80.2425, assigned: 'ER-2048' },
  { id: 'AMB-008', driver: 'M. Kannan', city: 'Coimbatore', status: 'Assigned', type: 'Basic Life Support', speed: 28, lat: 11.0168, lng: 76.9558, assigned: 'ER-2047' },
  { id: 'AMB-002', driver: 'J. David', city: 'Chennai', status: 'Available', type: 'Basic Life Support', speed: 0, lat: 12.975, lng: 80.22 },
  { id: 'AMB-021', driver: 'S. Ramesh', city: 'Bengaluru', status: 'Available', type: 'Advanced Life Support', speed: 0, lat: 12.9716, lng: 77.5946 },
  { id: 'AMB-019', driver: 'A. Imran', city: 'Hyderabad', status: 'Available', type: 'Basic Life Support', speed: 0, lat: 17.385, lng: 78.4867 },
  { id: 'AMB-011', driver: 'P. Nithya', city: 'Chennai', status: 'Available', type: 'Neonatal Ambulance', speed: 0, lat: 13.0827, lng: 80.2707 },
]
const hospitals: Hospital[] = [
  { name: 'City Central Hospital', city: 'Chennai', beds: 18, specialty: 'Cardiology, Trauma', status: 'Available', distance: '2.4 km' },
  { name: 'Kovai Medical Centre', city: 'Coimbatore', beds: 12, specialty: 'Trauma, ICU', status: 'Available', distance: '3.1 km' },
  { name: 'Metro Emergency Hospital', city: 'Bengaluru', beds: 9, specialty: 'Cardiology, Neurology', status: 'Available', distance: '1.8 km' },
  { name: 'Sunrise Multispeciality', city: 'Hyderabad', beds: 0, specialty: 'Trauma, ICU', status: 'At capacity', distance: '4.2 km' },
]
const traffic = [{ time: '08:00', requests: 34 }, { time: '09:00', requests: 48 }, { time: '10:00', requests: 42 }, { time: '11:00', requests: 71 }, { time: '12:00', requests: 56 }, { time: '13:00', requests: 88 }, { time: '14:00', requests: 63 }]
const navItems = [
  { name: 'Overview', icon: LayoutDashboard }, { name: 'Live Tracking', icon: MapPin },
  { name: 'Emergency Requests', icon: Siren }, { name: 'Ambulance Fleet', icon: Ambulance },
  { name: 'Hospitals', icon: Building2 }, { name: 'System Architecture', icon: Network },
  { name: 'Messaging & Alerts', icon: MessageSquare }, { name: 'Scalability Monitor', icon: Gauge },
  { name: 'Settings', icon: Settings },
]
const cities = ['All Cities', 'Chennai', 'Coimbatore', 'Bengaluru', 'Hyderabad']
const statusFlow: RequestStatus[] = ['Pending', 'Searching', 'Assigned', 'En Route', 'Arrived', 'Completed']
const uid = () => `ER-${Math.floor(2050 + Math.random() * 7000)}`

function App() {
  const [page, setPage] = useState('Overview')
  const [requests, setRequests] = useState(initialRequests)
  const [vehicles, setVehicles] = useState(initialVehicles)
  const [city, setCity] = useState('All Cities')
  const [query, setQuery] = useState('')
  const [showNew, setShowNew] = useState(false)
  const [selectedRequest, setSelectedRequest] = useState<Emergency | null>(null)
  const [toast, setToast] = useState('')
  const [trafficRunning, setTrafficRunning] = useState(false)
  const [trafficCount, setTrafficCount] = useState(100)
  const [cacheHits, setCacheHits] = useState(82)
  const [cacheMisses, setCacheMisses] = useState(18)
  const [cache, setCache] = useState<Record<string, string>>({})
  const [notifications, setNotifications] = useState([
    { id: 1, text: 'Critical emergency ER-2048 assigned to AMB-014', time: '2 min ago', unread: true },
    { id: 2, text: 'AMB-008 is en route to Avinashi Road', time: '5 min ago', unread: true },
    { id: 3, text: 'Hospital directory cache refreshed', time: '12 min ago', unread: false },
  ])
  const [showNotifications, setShowNotifications] = useState(false)
  const [form, setForm] = useState({ patient: '', phone: '', type: 'Accident', severity: 'High', city: 'Chennai', address: '', notes: '' })
  const [apiHealth, setApiHealth] = useState<'Demo mode' | 'Connected'>('Demo mode')

  useEffect(() => {
    fetch(`${import.meta.env.VITE_API_URL || 'http://localhost:4000/api'}/system/health`)
      .then(r => r.ok ? r.json() : Promise.reject()).then(() => setApiHealth('Connected')).catch(() => setApiHealth('Demo mode'))
  }, [])
  useEffect(() => {
    if (!trafficRunning) return
    const timer = window.setInterval(() => {
      setTrafficCount(v => Math.min(5000, v + 100))
      setCacheHits(v => v + 5)
    }, 1200)
    return () => window.clearInterval(timer)
  }, [trafficRunning])
  useEffect(() => {
    if (!toast) return
    const t = window.setTimeout(() => setToast(''), 3200)
    return () => window.clearTimeout(t)
  }, [toast])

  const activeRequests = requests.filter(r => !['Completed', 'Cancelled'].includes(r.status))
  const available = vehicles.filter(v => v.status === 'Available').length
  const filteredRequests = useMemo(() => requests.filter(r =>
    (city === 'All Cities' || r.city === city) &&
    `${r.id} ${r.patient} ${r.type} ${r.address}`.toLowerCase().includes(query.toLowerCase())
  ), [requests, city, query])
  const unread = notifications.filter(n => n.unread).length
  const cacheRatio = Math.round(cacheHits / Math.max(1, cacheHits + cacheMisses) * 100)

  function notify(text: string) {
    setToast(text)
    setNotifications(prev => [{ id: Date.now(), text, time: 'Just now', unread: true }, ...prev].slice(0, 12))
  }
  function createRequest(e: FormEvent) {
    e.preventDefault()
    if (!form.patient.trim() || !form.address.trim()) { notify('Please enter patient name and pickup address.'); return }
    const req: Emergency = { id: uid(), patient: form.patient, type: form.type, severity: form.severity, city: form.city, address: form.address, status: 'Pending', ambulance: 'Not assigned', time: 'Just now' }
    setRequests(prev => [req, ...prev])
    setShowNew(false)
    setForm({ patient: '', phone: '', type: 'Accident', severity: 'High', city: 'Chennai', address: '', notes: '' })
    notify(`Emergency ${req.id} created successfully`)
  }
  function assignAmbulance(req: Emergency) {
    const candidate = vehicles.find(v => v.city === req.city && v.status === 'Available') || vehicles.find(v => v.status === 'Available')
    if (!candidate) { notify('No available ambulance. Please try again shortly.'); return }
    setVehicles(prev => prev.map(v => v.id === candidate.id ? { ...v, status: 'Assigned', assigned: req.id, speed: 18 } : v))
    setRequests(prev => prev.map(r => r.id === req.id ? { ...r, status: 'Assigned', ambulance: candidate.id } : r))
    setSelectedRequest({ ...req, status: 'Assigned', ambulance: candidate.id })
    notify(`${candidate.id} assigned to ${req.id}`)
  }
  function updateStatus(req: Emergency, status: RequestStatus) {
    setRequests(prev => prev.map(r => r.id === req.id ? { ...r, status } : r))
    if (status === 'Completed' || status === 'Cancelled') setVehicles(prev => prev.map(v => v.assigned === req.id ? { ...v, status: 'Available', assigned: undefined, speed: 0 } : v))
    notify(`${req.id} status changed to ${status}`)
    setSelectedRequest({ ...req, status })
  }
  function cacheRead(key: string) {
    if (cache[key]) { setCacheHits(v => v + 1); notify(`Cache HIT: ${key}`) }
    else { setCacheMisses(v => v + 1); setCache(prev => ({ ...prev, [key]: new Date().toLocaleTimeString() })); notify(`Cache MISS: ${key} stored in demo cache`) }
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><HeartPulse size={22}/></div><div><strong>MediRescue</strong><small>EMERGENCY NETWORK</small></div></div>
      <div className="side-label">WORKSPACE</div>
      <nav>{navItems.map(item => { const Icon = item.icon; return <button key={item.name} className={`nav-item ${page === item.name ? 'active' : ''}`} onClick={() => setPage(item.name)}><Icon size={18}/><span>{item.name}</span>{item.name === 'Emergency Requests' && <b>{activeRequests.length}</b>}</button> })}</nav>
      <div className="sidebar-bottom"><div className="status-card"><span className="pulse-dot"/><div><strong>All systems operational</strong><small>Last checked just now</small></div></div><div className="profile"><div className="avatar">AD</div><div><strong>Admin Dispatcher</strong><small>Operations manager</small></div><ChevronDown size={16}/></div></div>
    </aside>
    <main className="main">
      <header className="topbar">
        <div className="mobile-brand"><div className="brand-mark"><HeartPulse size={19}/></div><strong>MediRescue</strong></div>
        <div className="breadcrumb"><span>Workspace</span><span className="slash">/</span><strong>{page}</strong></div>
        <div className="top-actions">
          <div className="searchbox"><Search size={16}/><input placeholder="Search anything..." value={query} onChange={e => setQuery(e.target.value)}/><kbd>⌘ K</kbd></div>
          <select className="city-select" value={city} onChange={e => setCity(e.target.value)} aria-label="Select city">{cities.map(c => <option key={c}>{c}</option>)}</select>
          <button className="icon-button notification-button" onClick={() => setShowNotifications(v => !v)} aria-label="Notifications"><Bell size={18}/>{unread > 0 && <i>{unread}</i>}</button>
          <span className={`mode-pill ${apiHealth === 'Connected' ? 'connected' : ''}`}><span className="pulse-dot"/>{apiHealth}</span>
        </div>
        {showNotifications && <div className="notification-popover"><div className="popover-head"><strong>Notifications</strong><button onClick={() => setNotifications(p => p.map(n => ({ ...n, unread: false })))}>Mark all read</button></div>{notifications.slice(0, 5).map(n => <div className="notification-row" key={n.id}><span className={n.unread ? 'unread-dot' : 'read-dot'}/><div><p>{n.text}</p><small>{n.time}</small></div></div>)}</div>}
      </header>
      <div className="content">
        <div className="page-heading"><div><div className="eyebrow"><span className="pulse-dot"/> EMERGENCY OPERATIONS CENTER</div><h1>{page}</h1><p>{page === 'Overview' ? 'Monitor emergency response activity across your connected cities.' : pageDescriptions[page] || 'Manage emergency operations and platform services.'}</p></div><div className="heading-actions"><span className="updated"><span className="pulse-dot"/> Live demo data</span><button className="button button-primary" onClick={() => setShowNew(true)}><Plus size={17}/> New emergency</button></div></div>
        {page === 'Overview' && <Overview requests={requests} vehicles={vehicles} activeRequests={activeRequests.length} available={available} onNew={() => setShowNew(true)} onView={r => { setSelectedRequest(r); setPage('Emergency Requests') }} />}
        {page === 'Live Tracking' && <Tracking vehicles={vehicles} requests={requests} city={city} onNotify={notify}/>}
        {page === 'Emergency Requests' && <RequestsPage requests={filteredRequests} query={query} setQuery={setQuery} onAssign={assignAmbulance} onSelect={setSelectedRequest} onNew={() => setShowNew(true)} onStatus={updateStatus}/>}
        {page === 'Ambulance Fleet' && <Fleet vehicles={vehicles} setVehicles={setVehicles} city={city} onNotify={notify}/>}
        {page === 'Hospitals' && <HospitalsPage hospitals={hospitals.filter(h => city === 'All Cities' || h.city === city)} onCache={() => cacheRead('hospital-directory')}/>}
        {page === 'System Architecture' && <Architecture/>}
        {page === 'Messaging & Alerts' && <Messaging notifications={notifications} setNotifications={setNotifications} onNotify={notify}/>}
        {page === 'Scalability Monitor' && <Scalability running={trafficRunning} setRunning={setTrafficRunning} count={trafficCount} setCount={setTrafficCount} cacheHits={cacheHits} cacheMisses={cacheMisses} cacheRatio={cacheRatio} onCache={cacheRead} onReset={() => {setTrafficCount(100);setTrafficRunning(false);setCacheHits(82);setCacheMisses(18);setCache({});notify('Demo metrics reset')}} cache={cache}/>}
        {page === 'Settings' && <SettingsPage apiHealth={apiHealth} onNotify={notify}/>}
      </div>
      <footer><span>© 2026 MediRescue Dispatch Platform</span><span><span className="pulse-dot"/> Demo environment <span className="footer-sep">·</span> Built for system design demonstration</span></footer>
    </main>
    {showNew && <div className="modal-backdrop" onClick={() => setShowNew(false)}><div className="modal" onClick={e => e.stopPropagation()}><div className="modal-head"><div><span className="eyebrow">DISPATCH CENTER</span><h2>Create emergency request</h2></div><button className="icon-button" onClick={() => setShowNew(false)}><X size={18}/></button></div><form onSubmit={createRequest} className="request-form">
      <label>Patient name *<input value={form.patient} onChange={e => setForm({...form, patient:e.target.value})} placeholder="Enter patient name" required/></label>
      <label>Contact number<input value={form.phone} onChange={e => setForm({...form, phone:e.target.value})} placeholder="+91 98765 43210"/></label>
      <div className="form-grid"><label>Emergency type<select value={form.type} onChange={e => setForm({...form,type:e.target.value})}>{['Accident','Cardiac emergency','Medical emergency','Fire injury','Other'].map(x=><option key={x}>{x}</option>)}</select></label><label>Severity<select value={form.severity} onChange={e => setForm({...form,severity:e.target.value})}>{['Critical','High','Medium','Low'].map(x=><option key={x}>{x}</option>)}</select></label></div>
      <div className="form-grid"><label>City<select value={form.city} onChange={e => setForm({...form,city:e.target.value})}>{cities.slice(1).map(x=><option key={x}>{x}</option>)}</select></label><label>Pickup address *<input value={form.address} onChange={e => setForm({...form,address:e.target.value})} placeholder="Street, landmark..." required/></label></div>
      <label>Additional notes<textarea value={form.notes} onChange={e => setForm({...form,notes:e.target.value})} placeholder="Describe the situation..." rows={2}/></label>
      <div className="modal-actions"><button type="button" className="button button-secondary" onClick={() => setShowNew(false)}>Cancel</button><button className="button button-primary" type="submit"><Siren size={16}/> Create request</button></div>
    </form></div></div>}
    {selectedRequest && <div className="drawer-backdrop" onClick={() => setSelectedRequest(null)}><aside className="detail-drawer" onClick={e => e.stopPropagation()}><div className="drawer-head"><div><span className="eyebrow">REQUEST DETAILS</span><h2>{selectedRequest.id}</h2></div><button className="icon-button" onClick={() => setSelectedRequest(null)}><X size={18}/></button></div><div className="drawer-content"><div className="severity-banner"><Siren size={20}/><div><strong>{selectedRequest.severity} priority</strong><small>{selectedRequest.type}</small></div><StatusBadge status={selectedRequest.status}/></div><div className="detail-list"><Detail label="Patient" value={selectedRequest.patient}/><Detail label="City" value={selectedRequest.city}/><Detail label="Pickup location" value={selectedRequest.address}/><Detail label="Assigned ambulance" value={selectedRequest.ambulance}/><Detail label="Created" value={selectedRequest.time}/></div><h3>Request progress</h3><div className="progress-list">{statusFlow.map((s,i)=>{const idx=statusFlow.indexOf(selectedRequest.status);return <div className={`progress-item ${i<=idx?'done':''}`} key={s}><span>{i<idx?<Check size={12}/>:i+1}</span><div><strong>{s}</strong><small>{i<idx?'Completed':i===idx?'Current status':'Waiting'}</small></div></div>})}</div><div className="drawer-actions">{selectedRequest.status === 'Pending' || selectedRequest.status === 'Searching' ? <button className="button button-primary full" onClick={() => assignAmbulance(selectedRequest)}><Ambulance size={16}/> Assign nearest ambulance</button> : null}{selectedRequest.status !== 'Completed' && selectedRequest.status !== 'Cancelled' && <><label className="field-label">Update status<select value={selectedRequest.status} onChange={e => updateStatus(selectedRequest,e.target.value as RequestStatus)}>{statusFlow.filter(s => s !== 'Pending').map(s=><option key={s}>{s}</option>)}</select></label><button className="button button-danger full" onClick={() => updateStatus(selectedRequest,'Cancelled')}><Ban size={16}/> Cancel request</button></>}</div></div></aside></div>}
    {toast && <div className="toast"><CheckCircle2 size={18}/>{toast}<button onClick={() => setToast('')}><X size={14}/></button></div>}
  </div>
}

const pageDescriptions: Record<string,string> = {
  'Live Tracking':'Monitor ambulance locations and dispatch status across the network.',
  'Emergency Requests':'Create, assign, track, and manage emergency calls.',
  'Ambulance Fleet':'Manage fleet availability, drivers, and active assignments.',
  'Hospitals':'Find destination hospitals and view demo capacity information.',
  'System Architecture':'Explore the platform services and their communication paths.',
  'Messaging & Alerts':'Review event-driven notifications and dispatch alerts.',
  'Scalability Monitor':'Simulate traffic spikes and monitor platform performance.',
  'Settings':'Review demo environment and platform configuration.'
}

function Overview({requests,vehicles,activeRequests,available,onNew,onView}:{requests:Emergency[],vehicles:Vehicle[],activeRequests:number,available:number,onNew:()=>void,onView:(r:Emergency)=>void}) {
  const critical = requests.filter(r => r.severity === 'Critical' && !['Completed','Cancelled'].includes(r.status)).length
  const stats = [
    {label:'Total emergencies',value:requests.length.toString(),change:'+12.8%',icon:Siren,tone:'red',sub:'Across all cities'},
    {label:'Active emergencies',value:activeRequests.toString(),change:'Live',icon:Activity,tone:'orange',sub:'Require attention'},
    {label:'Available ambulances',value:available.toString(),change:`/${vehicles.length}`,icon:Ambulance,tone:'green',sub:'Ready for dispatch'},
    {label:'Avg. response time',value:'08:42',change:'−1.4 min',icon:Clock3,tone:'blue',sub:'Today · demo metric'},
  ]
  return <div className="page-stack">
    <div className="stats-grid">{stats.map(s=>{const Icon=s.icon;return <div className="stat-card" key={s.label}><div className="stat-top"><span>{s.label}</span><div className={`stat-icon ${s.tone}`}><Icon size={19}/></div></div><div className="stat-value">{s.value}<span className="stat-change">{s.change}</span></div><div className="stat-sub">{s.sub}</div></div>})}</div>
    <div className="main-grid">
      <section className="panel chart-panel"><div className="panel-heading"><div><h3>Emergency activity</h3><p>Incoming requests throughout today</p></div><button className="subtle-button">Last 7 hours <ChevronDown size={14}/></button></div><div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={traffic} margin={{top:8,right:10,left:-20,bottom:0}}><defs><linearGradient id="redFade" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#ef4444" stopOpacity={0.2}/><stop offset="100%" stopColor="#ef4444" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f4"/><XAxis dataKey="time" tickLine={false} axisLine={false} tick={{fontSize:11,fill:'#8a94a6'}}/><YAxis tickLine={false} axisLine={false} tick={{fontSize:11,fill:'#8a94a6'}}/><Tooltip/><Area type="monotone" dataKey="requests" stroke="#e34444" strokeWidth={2.5} fill="url(#redFade)"/></AreaChart></ResponsiveContainer></div><div className="chart-foot"><span><i className="legend-dot red-dot"/>Emergency requests</span><span>Peak: 88 requests at 13:00</span></div></section>
      <section className="panel fleet-panel"><div className="panel-heading"><div><h3>Fleet availability</h3><p>Current ambulance status</p></div><span className="tiny-live"><span className="pulse-dot"/> Live</span></div><div className="donut-wrap"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={[{name:'Available',value:vehicles.filter(v=>v.status==='Available').length},{name:'On duty',value:vehicles.filter(v=>v.status!=='Available').length}]} innerRadius={59} outerRadius={79} paddingAngle={4} dataKey="value" stroke="none">{['#16a779','#e9a23b'].map(c=><Cell key={c} fill={c}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer><div className="donut-center"><strong>{vehicles.length}</strong><small>Total units</small></div></div><div className="fleet-legend"><div><span className="legend-dot green-dot"/>Available <strong>{vehicles.filter(v=>v.status==='Available').length}</strong></div><div><span className="legend-dot orange-dot"/>On duty <strong>{vehicles.filter(v=>v.status!=='Available').length}</strong></div></div><div className="fleet-note"><ShieldCheck size={16}/><span>{available} units ready for dispatch</span></div></section>
    </div>
    <div className="lower-grid"><section className="panel"><div className="panel-heading"><div><h3>Recent emergency requests</h3><p>Latest calls from connected cities</p></div><button className="text-button" onClick={()=>onView(requests[0])}>View details <ArrowUpRight size={14}/></button></div><div className="table-scroll"><table><thead><tr><th>REQUEST</th><th>TYPE</th><th>LOCATION</th><th>PRIORITY</th><th>STATUS</th><th></th></tr></thead><tbody>{requests.slice(0,5).map(r=><tr key={r.id} onClick={()=>onView(r)} className="click-row"><td><strong>{r.id}</strong><small>{r.time}</small></td><td>{r.type}</td><td><span className="location-cell"><MapPin size={13}/>{r.city}</span></td><td><SeverityBadge severity={r.severity}/></td><td><StatusBadge status={r.status}/></td><td><button className="row-action" onClick={e=>{e.stopPropagation();onView(r)}}>→</button></td></tr>)}</tbody></table></div></section>
    <section className="panel city-panel"><div className="panel-heading"><div><h3>City operations</h3><p>Network overview by region</p></div><button className="icon-button small"><ArrowUpRight size={15}/></button></div>{['Chennai','Coimbatore','Bengaluru','Hyderabad'].map((c,i)=>{const count=requests.filter(r=>r.city===c&&!['Completed','Cancelled'].includes(r.status)).length;return <div className="city-row" key={c}><div className={`city-symbol city-${i}`}><Building2 size={16}/></div><div className="city-info"><strong>{c}</strong><small>{vehicles.filter(v=>v.city===c&&v.status==='Available').length} ambulances available</small></div><div className="city-count"><strong>{count}</strong><small>active</small></div></div>})}<button className="button button-secondary full" onClick={onNew}><Plus size={15}/> Create emergency request</button></section></div>
    {critical>0&&<div className="alert-banner"><div className="alert-symbol"><Siren size={19}/></div><div><strong>{critical} critical emergency {critical===1?'requires':'require'} attention</strong><p>Prioritize dispatch and ensure the nearest available ambulance is assigned.</p></div><span className="alert-tag">HIGH PRIORITY</span></div>}
  </div>
}

function RequestsPage({requests,query,setQuery,onAssign,onSelect,onNew,onStatus}:{requests:Emergency[],query:string,setQuery:(s:string)=>void,onAssign:(r:Emergency)=>void,onSelect:(r:Emergency)=>void,onNew:()=>void,onStatus:(r:Emergency,s:RequestStatus)=>void}) {
  const [filter,setFilter]=useState('All')
  const rows=requests.filter(r=>filter==='All'||r.status===filter)
  return <div className="page-stack"><div className="toolbar panel"><div className="tabs">{['All','Pending','Searching','Assigned','En Route','Completed'].map(s=><button className={filter===s?'selected':''} onClick={()=>setFilter(s)} key={s}>{s}</button>)}</div><button className="button button-primary" onClick={onNew}><Plus size={16}/> New request</button></div><section className="panel"><div className="panel-heading"><div><h3>Emergency request queue</h3><p>{rows.length} requests match your filters</p></div><div className="table-tools"><span className="searchbox table-search"><Search size={15}/><input placeholder="Search requests..." value={query} onChange={e=>setQuery(e.target.value)}/></span><button className="icon-button" onClick={()=>setQuery('')} title="Clear search"><RefreshCw size={16}/></button></div></div><div className="table-scroll"><table><thead><tr><th>REQUEST / PATIENT</th><th>EMERGENCY</th><th>LOCATION</th><th>PRIORITY</th><th>AMBULANCE</th><th>STATUS</th><th>ACTION</th></tr></thead><tbody>{rows.map(r=><tr key={r.id} className="click-row"><td><strong>{r.id}</strong><small>{r.patient}</small></td><td>{r.type}</td><td><span className="location-cell"><MapPin size={13}/>{r.city}</span></td><td><SeverityBadge severity={r.severity}/></td><td>{r.ambulance}</td><td><StatusBadge status={r.status}/></td><td><div className="action-buttons"><button className="row-action" title="Details" onClick={()=>onSelect(r)}>↗</button>{['Pending','Searching'].includes(r.status)&&<button className="mini-action" onClick={()=>onAssign(r)}>Assign</button>}{r.status==='Assigned'&&<button className="mini-action" onClick={()=>onStatus(r,'En Route')}>En route</button>}</div></td></tr>)}</tbody></table>{rows.length===0&&<div className="empty-state"><CircleHelp size={28}/><strong>No requests found</strong><span>Try changing your filters or search term.</span></div>}</div></section></div>
}

function Tracking({vehicles,requests,city,onNotify}:{vehicles:Vehicle[],requests:Emergency[],city:string,onNotify:(s:string)=>void}) {
  const [selected,setSelected]=useState(vehicles[0]?.id||'')
  const [moving,setMoving]=useState(false)
  const filtered=vehicles.filter(v=>city==='All Cities'||v.city===city)
  useEffect(()=>{if(!filtered.some(v=>v.id===selected)&&filtered[0])setSelected(filtered[0].id)},[city,selected])
  const vehicle=vehicles.find(v=>v.id===selected)
  return <div className="page-stack"><div className="tracking-summary"><div className="mini-stat"><div className="stat-icon green"><Ambulance size={18}/></div><div><strong>{filtered.filter(v=>v.status==='Available').length}</strong><small>Available</small></div></div><div className="mini-stat"><div className="stat-icon orange"><Radio size={18}/></div><div><strong>{filtered.filter(v=>v.status!=='Available').length}</strong><small>Active trips</small></div></div><div className="mini-stat"><div className="stat-icon blue"><MapPin size={18}/></div><div><strong>{filtered.length}</strong><small>Tracked units</small></div></div><button className="button button-secondary" onClick={()=>{setMoving(v=>!v);onNotify(moving?'Tracking simulation paused':'Tracking simulation started')}}>{moving?'Pause simulation':'Simulate movement'} <Activity size={15}/></button></div><div className="tracking-layout"><section className="panel map-panel"><div className="panel-heading"><div><h3>Network location overview</h3><p>Illustrative city locations · demo coordinates</p></div><span className="tiny-live"><span className="pulse-dot"/> Simulated</span></div><div className="map-visual"><div className="map-grid"/><div className="map-river"/><div className="map-road road-a"/><div className="map-road road-b"/><div className="map-road road-c"/><div className="map-label label-a">CITY CENTER</div><div className="map-label label-b">HOSPITAL ZONE</div><div className="map-label label-c">NORTH DISTRICT</div>{filtered.map((v,i)=><button key={v.id} className={`map-pin pin-${i%6} ${selected===v.id?'pin-selected':''}`} style={{left:`${15+(i*17)%70}%`,top:`${18+(i*23)%62}%`}} onClick={()=>setSelected(v.id)} title={v.id}><Ambulance size={16}/></button>)}<div className="map-legend"><span><i className="legend-dot green-dot"/> Available</span><span><i className="legend-dot orange-dot"/> On duty</span><span><i className="legend-dot red-dot"/> Selected</span></div><div className="map-watermark">MEDIRESCUE NETWORK MAP · DEMO</div></div><div className="map-foot"><span><MapPin size={14}/> {city==='All Cities'?'All connected cities':city}</span><span>Updated just now</span></div></section><section className="panel vehicle-list-panel"><div className="panel-heading"><div><h3>Tracked ambulances</h3><p>Select a vehicle for details</p></div><span className="count-pill">{filtered.length}</span></div><div className="vehicle-list">{filtered.map(v=><button className={`vehicle-row ${selected===v.id?'vehicle-selected':''}`} key={v.id} onClick={()=>setSelected(v.id)}><div className={`vehicle-icon ${v.status==='Available'?'available':'busy'}`}><Ambulance size={19}/></div><div className="vehicle-main"><strong>{v.id}</strong><small>{v.city} · {v.driver}</small><span className={`text-status ${v.status==='Available'?'green-text':'orange-text'}`}>{v.status}</span></div><ChevronDown size={15}/></button>)}</div>{vehicle&&<div className="vehicle-detail"><span className="eyebrow">SELECTED VEHICLE</span><h3>{vehicle.id}</h3><Detail label="Driver" value={vehicle.driver}/><Detail label="Vehicle type" value={vehicle.type}/><Detail label="Speed" value={`${moving&&vehicle.speed?vehicle.speed+3:vehicle.speed} km/h`}/><Detail label="Coordinates" value={`${vehicle.lat.toFixed(4)}, ${vehicle.lng.toFixed(4)}`}/><Detail label="Assigned request" value={vehicle.assigned||'None'}/><button className="button button-secondary full" onClick={()=>onNotify(`Location refreshed for ${vehicle.id}`)}><RefreshCw size={15}/> Refresh location</button></div>}</section></div><div className="panel table-panel"><div className="panel-heading"><div><h3>Active dispatch routes</h3><p>Emergency destinations linked to ambulances</p></div></div><div className="table-scroll"><table><thead><tr><th>REQUEST</th><th>PICKUP</th><th>AMBULANCE</th><th>STATUS</th><th>LAST UPDATE</th></tr></thead><tbody>{requests.filter(r=>!['Completed','Cancelled'].includes(r.status)).map(r=><tr key={r.id}><td><strong>{r.id}</strong></td><td>{r.address}</td><td>{r.ambulance}</td><td><StatusBadge status={r.status}/></td><td>Just now (demo)</td></tr>)}</tbody></table></div></div></div>
}

function Fleet({vehicles,setVehicles,city,onNotify}:{vehicles:Vehicle[],setVehicles:Dispatch<SetStateAction<Vehicle[]>>,city:string,onNotify:(s:string)=>void}) {
 const [search,setSearch]=useState('')
 const rows=vehicles.filter(v=>(city==='All Cities'||v.city===city)&&`${v.id} ${v.driver} ${v.city}`.toLowerCase().includes(search.toLowerCase()))
 const [add,setAdd]=useState(false)
 return <div className="page-stack"><div className="stats-grid compact-stats"><Stat label="Total fleet" value={vehicles.length.toString()} icon={Truck} tone="blue"/><Stat label="Available" value={vehicles.filter(v=>v.status==='Available').length.toString()} icon={CheckCircle2} tone="green"/><Stat label="On duty" value={vehicles.filter(v=>v.status!=='Available').length.toString()} icon={Activity} tone="orange"/><Stat label="Cities covered" value="4" icon={Building2} tone="red"/></div><section className="panel"><div className="panel-heading"><div><h3>Ambulance fleet</h3><p>Manage vehicles, driver information and readiness</p></div><button className="button button-primary" onClick={()=>setAdd(true)}><Plus size={16}/> Add ambulance</button></div><div className="table-tools fleet-tools"><span className="searchbox table-search"><Search size={15}/><input placeholder="Search fleet..." value={search} onChange={e=>setSearch(e.target.value)}/></span></div><div className="table-scroll"><table><thead><tr><th>VEHICLE</th><th>DRIVER</th><th>CITY</th><th>TYPE</th><th>STATUS</th><th>ASSIGNMENT</th><th>ACTION</th></tr></thead><tbody>{rows.map(v=><tr key={v.id}><td><strong>{v.id}</strong><small>Emergency unit</small></td><td>{v.driver}</td><td>{v.city}</td><td>{v.type}</td><td><StatusBadge status={v.status as RequestStatus}/></td><td>{v.assigned||'—'}</td><td><button className="mini-action" onClick={()=>{setVehicles(prev=>prev.map(x=>x.id===v.id?{...x,status:x.status==='Available'?'Offline':'Available',assigned:undefined,speed:0}:x));onNotify(`${v.id} availability updated`)}}>Toggle availability</button></td></tr>)}</tbody></table></div></section>{add&&<div className="inline-form panel"><strong>Add ambulance</strong><p>Quickly add a demo fleet unit.</p><button className="button button-primary" onClick={()=>{const id=`AMB-${String(Math.floor(22+Math.random()*70)).padStart(3,'0')}`;setVehicles(p=>[...p,{id,driver:'New Driver',city:city==='All Cities'?'Chennai':city,status:'Available',type:'Basic Life Support',speed:0,lat:13.05,lng:80.24}]);setAdd(false);onNotify(`${id} added to fleet`)}}>Confirm add demo unit</button><button className="button button-secondary" onClick={()=>setAdd(false)}>Cancel</button></div>}</div>
}

function HospitalsPage({hospitals,onCache}:{hospitals:Hospital[],onCache:()=>void}) {
 return <div className="page-stack"><div className="stats-grid compact-stats"><Stat label="Hospitals listed" value={hospitals.length.toString()} icon={Building2} tone="blue"/><Stat label="Emergency available" value={hospitals.filter(h=>h.status==='Available').length.toString()} icon={HeartPulse} tone="green"/><Stat label="Beds available (demo)" value={hospitals.reduce((n,h)=>n+h.beds,0).toString()} icon={ShieldCheck} tone="orange"/><Stat label="Cities" value={new Set(hospitals.map(h=>h.city)).size.toString()} icon={MapPin} tone="red"/></div><section className="panel"><div className="panel-heading"><div><h3>Hospital directory</h3><p>Destination facilities and illustrative capacity</p></div><button className="button button-secondary" onClick={onCache}><Database size={16}/> Read cached directory</button></div><div className="hospital-grid">{hospitals.map((h,i)=><div className="hospital-card" key={h.name}><div className="hospital-top"><div className="hospital-symbol"><Building2 size={22}/></div><StatusBadge status={h.status==='Available'?'Available':'Pending'}/></div><h3>{h.name}</h3><p><MapPin size={14}/>{h.city}</p><div className="hospital-meta"><div><strong>{h.beds}</strong><small>Demo beds</small></div><div><strong>{h.distance}</strong><small>Illustrative distance</small></div></div><div className="specialty">{h.specialty}</div><button className="button button-secondary full" onClick={()=>alert(`${h.name}\\n${h.city}\\nSpecialties: ${h.specialty}\\nDemo beds: ${h.beds}`)}>View hospital details</button></div>)}</div><div className="info-note"><CircleHelp size={16}/><span>Hospital capacity and distances are sample data for this project. Confirm availability with the hospital in real deployments.</span></div></section></div>
}

function Architecture() {
 const [selected,setSelected]=useState('API Gateway')
 const [showFlow,setShowFlow]=useState(true)
 const nodes=[
  {name:'Client Applications',type:'Frontend',desc:'Patient mobile app and dispatcher web dashboard. Submit emergency requests and receive updates.',color:'node-blue'},
  {name:'Load Balancer',type:'Traffic',desc:'Distributes incoming requests across healthy API instances and avoids a single overloaded server.',color:'node-purple'},
  {name:'API Gateway',type:'Gateway',desc:'Express.js entry point. Routes requests, validates inputs, applies rate limits and authentication, and returns consistent responses.',color:'node-red'},
  {name:'Emergency Service',type:'Backend',desc:'Creates emergency requests, maintains request status and coordinates the dispatch workflow.',color:'node-orange'},
  {name:'Dispatch Service',type:'Backend',desc:'Finds nearby available ambulances and uses a transactional assignment to prevent double booking.',color:'node-orange'},
  {name:'Location Service',type:'Realtime',desc:'Receives GPS updates, updates latest locations in Redis and broadcasts changes over Socket.IO.',color:'node-green'},
  {name:'Hospital Service',type:'Backend',desc:'Stores hospital directory data and provides destination information and capacity metadata.',color:'node-orange'},
  {name:'PostgreSQL',type:'Database',desc:'Persistent relational records for users, ambulances, hospitals, emergency requests, and audit history.',color:'node-dark'},
  {name:'Redis Cache',type:'Cache',desc:'Fast reads for latest ambulance positions, nearby vehicle lookup and frequently accessed hospital data. Cache is not the source of truth for assignments.',color:'node-pink'},
  {name:'RabbitMQ',type:'Messaging',desc:'Asynchronous events for new requests, ambulance assignment, status changes and notifications. Retries and dead-letter queues help recover from failures.',color:'node-yellow'},
 ]
 const node=(name:string)=>nodes.find(n=>n.name===name)!
 return <div className="page-stack"><div className="architecture-intro"><div className="arch-intro-icon"><Network size={24}/></div><div><h3>Distributed emergency dispatch architecture</h3><p>Explore the main components and how requests travel through the system.</p></div><span className="architecture-tag">HIGH-LEVEL DESIGN</span></div><section className="panel architecture-panel"><div className="panel-heading"><div><h3>Service topology</h3><p>Click a component to see its responsibilities</p></div><button className="button button-secondary" onClick={()=>setShowFlow(v=>!v)}>{showFlow?'Hide request flow':'Show request flow'}</button></div><div className="architecture-canvas"><div className="arch-layer"><span className="layer-label">CLIENT LAYER</span><button className={`arch-node ${node('Client Applications').color} ${selected==='Client Applications'?'node-selected':''}`} onClick={()=>setSelected('Client Applications')}><Users size={17}/> Client Applications<small>Web + mobile</small></button></div><div className="connector">↓ HTTPS / REST</div><div className="arch-layer"><span className="layer-label">TRAFFIC MANAGEMENT</span><button className={`arch-node ${node('Load Balancer').color} ${selected==='Load Balancer'?'node-selected':''}`} onClick={()=>setSelected('Load Balancer')}><Activity size={17}/> Load Balancer<small>Health checks</small></button><div className="connector">↓</div><button className={`arch-node ${node('API Gateway').color} ${selected==='API Gateway'?'node-selected':''}`} onClick={()=>setSelected('API Gateway')}><ShieldCheck size={17}/> API Gateway<small>Express.js · Auth · Routing</small></button></div><div className="connector">↓ REST + service events</div><div className="arch-layer service-layer"><span className="layer-label">BACKEND MICROSERVICES</span>{['Emergency Service','Dispatch Service','Location Service','Hospital Service'].map((name,i)=><button key={name} className={`arch-node ${node(name).color} ${selected===name?'node-selected':''}`} onClick={()=>setSelected(name)}>{i===0?<Siren size={17}/>:i===1?<Ambulance size={17}/>:i===2?<MapPin size={17}/>:<Building2 size={17}/>} {name}<small>{['Request lifecycle','Nearest vehicle','GPS + Socket.IO','Hospital directory'][i]}</small></button>)}</div><div className="connector">↓ persistence · cache · async events</div><div className="arch-layer data-layer"><span className="layer-label">DATA & MESSAGING</span>{['PostgreSQL','Redis Cache','RabbitMQ'].map((name,i)=><button key={name} className={`arch-node ${node(name).color} ${selected===name?'node-selected':''}`} onClick={()=>setSelected(name)}>{i===0?<Database size={17}/>:i===1?<Zap size={17}/>:<MessageSquare size={17}/>} {name}<small>{['Durable records','Fast location reads','Event queue'][i]}</small></button>)}</div></div><div className="component-detail"><div className={`detail-icon ${node(selected).color}`}><Server size={21}/></div><div><div className="detail-title-row"><span className="eyebrow">{node(selected).type} COMPONENT</span><strong>{selected}</strong></div><p>{node(selected).desc}</p></div></div>{showFlow&&<div className="request-flow"><h3><Activity size={17}/> Emergency request lifecycle</h3><div className="flow-steps">{['User submits request','Gateway validates','Request saved','Dispatch finds nearest unit','Event published','Client gets live update'].map((s,i)=><div className="flow-step" key={s}><span>{i+1}</span><strong>{s}</strong>{i<5&&<b>→</b>}</div>)}</div></div>}</section><div className="info-note"><CircleHelp size={16}/><span>Architecture note: this is a logical design. Redis, RabbitMQ, PostgreSQL and Socket.IO are configured as integration targets; demo mode can simulate their behavior locally.</span></div></div>
}

function Messaging({notifications,setNotifications,onNotify}:{notifications:{id:number;text:string;time:string;unread:boolean}[],setNotifications:Dispatch<SetStateAction<{id:number;text:string;time:string;unread:boolean}[]>>,onNotify:(s:string)=>void}) {
 const [event,setEvent]=useState('emergency.request.created')
 const events=['emergency.request.created','emergency.request.cancelled','ambulance.assigned','ambulance.location.updated','emergency.status.changed','notification.created']
 return <div className="page-stack"><div className="stats-grid compact-stats"><Stat label="Events today (demo)" value="1,284" icon={MessageSquare} tone="blue"/><Stat label="Queue depth" value="12" icon={Activity} tone="orange"/><Stat label="Consumers healthy" value="6 / 6" icon={CheckCircle2} tone="green"/><Stat label="Unread alerts" value={notifications.filter(n=>n.unread).length.toString()} icon={Bell} tone="red"/></div><div className="two-column"><section className="panel"><div className="panel-heading"><div><h3>Event simulator</h3><p>Publish a sample dispatch event</p></div><span className="tiny-live"><span className="pulse-dot"/> Demo broker</span></div><label className="field-label">Event type<select value={event} onChange={e=>setEvent(e.target.value)}>{events.map(e=><option key={e}>{e}</option>)}</select></label><div className="code-preview"><div><span/> <span/> <span/> <small>event payload · JSON</small></div><pre>{JSON.stringify({eventId:`evt_${Date.now().toString().slice(-6)}`,type:event,city:'Chennai',timestamp:new Date().toISOString(),source:'medirescue-demo'},null,2)}</pre></div><button className="button button-primary" onClick={()=>onNotify(`Event published: ${event}`)}><Send size={16}/> Publish demo event</button><div className="info-note"><CircleHelp size={16}/><span>In production, publish to RabbitMQ and process through durable consumers with retry and dead-letter handling.</span></div></section><section className="panel"><div className="panel-heading"><div><h3>Event processing pipeline</h3><p>Asynchronous event flow</p></div></div><div className="pipeline">{[{n:'01',title:'Event producer',desc:'Emergency or dispatch service emits event'},{n:'02',title:'Message broker',desc:'RabbitMQ queues event durably'},{n:'03',title:'Consumer service',desc:'Worker validates and processes event'},{n:'04',title:'Notification channel',desc:'Socket.IO pushes update to clients'}].map((x,i)=><div className="pipeline-item" key={x.n}><span>{x.n}</span><div><strong>{x.title}</strong><small>{x.desc}</small></div>{i<3&&<div className="pipeline-line"/>}</div>)}</div></section></div><section className="panel"><div className="panel-heading"><div><h3>Notification center</h3><p>Recent system and dispatch events</p></div><button className="text-button" onClick={()=>setNotifications(p=>p.map(n=>({...n,unread:false})))}>Mark all read</button></div><div className="notification-list">{notifications.map(n=><div className="notification-item" key={n.id}><div className={`notification-icon ${n.unread?'notice-new':''}`}><Bell size={17}/></div><div className="notification-message"><strong>{n.text}</strong><small>{n.time}</small></div>{n.unread&&<span className="unread-label">NEW</span>}<button className="icon-button small" onClick={()=>setNotifications(p=>p.map(x=>x.id===n.id?{...x,unread:false}:x))}><Check size={15}/></button></div>)}</div></section></div>
}

function Scalability({running,setRunning,count,setCount,cacheHits,cacheMisses,cacheRatio,onCache,onReset,cache}:{running:boolean,setRunning:(v:boolean)=>void,count:number,setCount:(v:number)=>void,cacheHits:number,cacheMisses:number,cacheRatio:number,onCache:(k:string)=>void,onReset:()=>void,cache:Record<string,string>}) {
 const data=[{name:'100',requests:100,latency:120},{name:'500',requests:500,latency:155},{name:'1k',requests:1000,latency:182},{name:'2.5k',requests:2500,latency:230},{name:'5k',requests:5000,latency:310}]
 return <div className="page-stack"><div className="monitor-banner"><div><div className="eyebrow">LOAD SIMULATION</div><h2>Scalability & system health</h2><p>Demonstrate how the architecture responds to traffic spikes.</p></div><div className="sim-controls"><button className={`button ${running?'button-danger':'button-primary'}`} onClick={()=>setRunning(!running)}>{running?'Stop simulation':'Start traffic simulation'} <Activity size={16}/></button><button className="button button-secondary" onClick={onReset}><RefreshCw size={15}/> Reset</button></div></div><div className="stats-grid"><Stat label="Simulated requests" value={count.toLocaleString()} icon={Activity} tone="red"/><Stat label="Requests / sec (demo)" value={running?'125':'0'} icon={Zap} tone="orange"/><Stat label="Avg API latency (demo)" value={count>2500?'310 ms':count>1000?'230 ms':'142 ms'} icon={Clock3} tone="blue"/><Stat label="Cache hit ratio" value={`${cacheRatio}%`} icon={Database} tone="green"/></div><div className="main-grid"><section className="panel"><div className="panel-heading"><div><h3>Traffic capacity profile</h3><p>Illustrative load-test profile, not a live benchmark</p></div></div><div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><BarChart data={data}><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f4"/><XAxis dataKey="name" tickLine={false} axisLine={false}/><YAxis tickLine={false} axisLine={false}/><Tooltip/><Bar dataKey="requests" fill="#4f7de8" radius={[5,5,0,0]}/></BarChart></ResponsiveContainer></div></section><section className="panel"><div className="panel-heading"><div><h3>Infrastructure health</h3><p>Demo status indicators</p></div><span className="tiny-live"><span className="pulse-dot"/> Nominal</span></div><div className="health-list">{[['API Gateway','Operational','99.98%'],['PostgreSQL','Demo / configured','Healthy'],['Redis Cache','Demo / configured','Healthy'],['RabbitMQ','Demo / configured','Healthy'],['Socket.IO','Frontend simulation','Active']].map(x=><div className="health-row" key={x[0]}><div className="health-check"><Check size={14}/></div><div><strong>{x[0]}</strong><small>{x[1]}</small></div><span>{x[2]}</span></div>)}</div></section></div><div className="two-column"><section className="panel"><div className="panel-heading"><div><h3>Redis cache demo</h3><p>Try a cache read to see hit and miss behavior</p></div></div><div className="cache-buttons"><button className="button button-secondary" onClick={()=>onCache('ambulance-location:AMB-014')}><MapPin size={15}/> Read ambulance location</button><button className="button button-secondary" onClick={()=>onCache('hospital-directory')}><Building2 size={15}/> Read hospital directory</button><button className="button button-secondary" onClick={()=>onCache('dashboard:stats')}><Gauge size={15}/> Read dashboard stats</button></div><div className="cache-stats"><div><small>Hits</small><strong>{cacheHits}</strong></div><div><small>Misses</small><strong>{cacheMisses}</strong></div><div><small>Hit ratio</small><strong>{cacheRatio}%</strong></div></div><div className="cached-keys"><strong>Cached keys</strong>{Object.entries(cache).map(([k,v])=><div key={k}><code>{k}</code><small>{v}</small></div>)}{Object.keys(cache).length===0&&<small>No keys cached yet. Click a read button above.</small>}</div></section><section className="panel"><div className="panel-heading"><div><h3>Scaling strategy</h3><p>How the platform handles surges</p></div></div><div className="strategy-list">{[['1','Load balancing','Distribute requests across healthy API instances.'],['2','Horizontal scaling','Add service replicas during peak traffic.'],['3','Queue-based processing','Process dispatch events asynchronously.'],['4','Caching & indexing','Reduce database reads and improve lookup speed.'],['5','Rate limiting','Protect services from overload and abuse.']].map(x=><div key={x[0]}><span>{x[0]}</span><div><strong>{x[1]}</strong><small>{x[2]}</small></div></div>)}</div></section></div><div className="info-note"><CircleHelp size={16}/><span>All traffic, latency, queue, and health values in this local simulator are illustrative. Real capacity must be verified with load tests and deployed infrastructure metrics.</span></div></div>
}

function SettingsPage({apiHealth,onNotify}:{apiHealth:string,onNotify:(s:string)=>void}) {
 return <div className="page-stack"><section className="panel settings-panel"><div className="panel-heading"><div><h3>Application settings</h3><p>Project configuration and demo environment</p></div></div><div className="setting-row"><div className="setting-icon"><Server size={19}/></div><div><strong>Backend API</strong><small>VITE_API_URL or http://localhost:4000/api</small></div><StatusBadge status={apiHealth==='Connected'?'Available':'Pending'}/></div><div className="setting-row"><div className="setting-icon"><Database size={19}/></div><div><strong>PostgreSQL database</strong><small>Schema and seed scripts are included in the server project.</small></div><span className="status-badge pending">Optional integration</span></div><div className="setting-row"><div className="setting-icon"><Zap size={19}/></div><div><strong>Redis cache</strong><small>Local demo cache works without Redis.</small></div><span className="status-badge pending">Demo fallback</span></div><div className="setting-row"><div className="setting-icon"><MessageSquare size={19}/></div><div><strong>RabbitMQ messaging</strong><small>Event simulator works without a message broker.</small></div><span className="status-badge pending">Demo fallback</span></div><div className="setting-row"><div className="setting-icon"><ShieldCheck size={19}/></div><div><strong>Security note</strong><small>Use real authentication, TLS, secrets and audit controls before production deployment.</small></div><span className="status-badge available">Demo mode</span></div><button className="button button-primary" onClick={()=>onNotify('Configuration checked. See README for optional integrations.')}><CheckCircle2 size={16}/> Check configuration</button></section></div>
}

function Stat({label,value,icon:Icon,tone}:{label:string,value:string,icon:any,tone:string}) { return <div className="stat-card"><div className="stat-top"><span>{label}</span><div className={`stat-icon ${tone}`}><Icon size={19}/></div></div><div className="stat-value">{value}</div><div className="stat-sub">Platform demo metric</div></div> }
function Detail({label,value}:{label:string,value:string}) { return <div className="detail-row"><span>{label}</span><strong>{value}</strong></div> }
function SeverityBadge({severity}:{severity:string}) { return <span className={`severity-badge ${severity.toLowerCase()}`}><i/>{severity}</span> }
function StatusBadge({status}:{status:string}) { const cls=status.toLowerCase().replaceAll(' ','-');return <span className={`status-badge ${cls}`}><i/>{status}</span> }

export default App
