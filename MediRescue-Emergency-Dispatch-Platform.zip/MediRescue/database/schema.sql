-- PostgreSQL starter schema for the MediRescue system design project.
CREATE TABLE IF NOT EXISTS users (
  id BIGSERIAL PRIMARY KEY, full_name TEXT NOT NULL, phone TEXT UNIQUE,
  role TEXT NOT NULL DEFAULT 'viewer', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS hospitals (
  id BIGSERIAL PRIMARY KEY, name TEXT NOT NULL, city TEXT NOT NULL, address TEXT,
  emergency_available BOOLEAN NOT NULL DEFAULT TRUE, available_beds INTEGER NOT NULL DEFAULT 0,
  specialties TEXT[] NOT NULL DEFAULT '{}', created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS ambulances (
  id TEXT PRIMARY KEY, registration TEXT UNIQUE, driver_name TEXT NOT NULL, city TEXT NOT NULL,
  vehicle_type TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'Available',
  latitude DOUBLE PRECISION, longitude DOUBLE PRECISION, updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS emergency_requests (
  id TEXT PRIMARY KEY, patient_name TEXT NOT NULL, contact_number TEXT,
  emergency_type TEXT NOT NULL, severity TEXT NOT NULL, city TEXT NOT NULL, pickup_address TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'Pending', ambulance_id TEXT REFERENCES ambulances(id),
  hospital_id BIGINT REFERENCES hospitals(id), notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS ambulance_locations (
  id BIGSERIAL PRIMARY KEY, ambulance_id TEXT NOT NULL REFERENCES ambulances(id),
  latitude DOUBLE PRECISION NOT NULL, longitude DOUBLE PRECISION NOT NULL,
  speed_kmh NUMERIC(6,2) DEFAULT 0, recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS notifications (
  id BIGSERIAL PRIMARY KEY, user_id BIGINT REFERENCES users(id), event_type TEXT NOT NULL,
  message TEXT NOT NULL, read_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS request_history (
  id BIGSERIAL PRIMARY KEY, request_id TEXT NOT NULL REFERENCES emergency_requests(id),
  old_status TEXT, new_status TEXT NOT NULL, changed_by BIGINT REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_requests_city_status ON emergency_requests(city, status);
CREATE INDEX IF NOT EXISTS idx_requests_created ON emergency_requests(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ambulances_city_status ON ambulances(city, status);
CREATE INDEX IF NOT EXISTS idx_locations_vehicle_time ON ambulance_locations(ambulance_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_hospitals_city ON hospitals(city);
