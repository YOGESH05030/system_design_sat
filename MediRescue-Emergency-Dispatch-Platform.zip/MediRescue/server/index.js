import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createServer } from 'node:http';
import { Server } from 'socket.io';
import { randomUUID } from 'node:crypto';

dotenv.config();
const app = express();
const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: '*' } });
app.use(cors());
app.use(express.json());
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} ${req.method} ${req.path}`);
  next();
});

const ambulances = [
  { id: 'AMB-014', driver: 'R. Suresh', city: 'Chennai', status: 'En Route', type: 'Advanced Life Support', lat: 13.0569, lng: 80.2425, assigned: 'ER-2048' },
  { id: 'AMB-008', driver: 'M. Kannan', city: 'Coimbatore', status: 'Assigned', type: 'Basic Life Support', lat: 11.0168, lng: 76.9558, assigned: 'ER-2047' },
  { id: 'AMB-002', driver: 'J. David', city: 'Chennai', status: 'Available', type: 'Basic Life Support', lat: 12.975, lng: 80.22 },
  { id: 'AMB-021', driver: 'S. Ramesh', city: 'Bengaluru', status: 'Available', type: 'Advanced Life Support', lat: 12.9716, lng: 77.5946 },
  { id: 'AMB-019', driver: 'A. Imran', city: 'Hyderabad', status: 'Available', type: 'Basic Life Support', lat: 17.385, lng: 78.4867 }
];
const requests = [
  { id: 'ER-2048', patient: 'Arun Kumar', type: 'Cardiac emergency', severity: 'Critical', city: 'Chennai', address: 'Anna Salai, Chennai', status: 'En Route', ambulance: 'AMB-014', createdAt: new Date().toISOString() },
  { id: 'ER-2047', patient: 'Priya S.', type: 'Road accident', severity: 'High', city: 'Coimbatore', address: 'Avinashi Road, Coimbatore', status: 'Assigned', ambulance: 'AMB-008', createdAt: new Date().toISOString() }
];
const hospitals = [
  { id: 'H-001', name: 'City Central Hospital', city: 'Chennai', beds: 18, specialty: 'Cardiology, Trauma', status: 'Available' },
  { id: 'H-002', name: 'Kovai Medical Centre', city: 'Coimbatore', beds: 12, specialty: 'Trauma, ICU', status: 'Available' },
  { id: 'H-003', name: 'Metro Emergency Hospital', city: 'Bengaluru', beds: 9, specialty: 'Cardiology, Neurology', status: 'Available' },
  { id: 'H-004', name: 'Sunrise Multispeciality', city: 'Hyderabad', beds: 0, specialty: 'Trauma, ICU', status: 'At capacity' }
];
const eventLog = [];
function event(type, payload) {
  const item = { id: randomUUID(), type, payload, timestamp: new Date().toISOString() };
  eventLog.unshift(item);
  io.emit('medirescue:event', item);
  return item;
}
function error(res, status, message) { return res.status(status).json({ error: { message, status } }); }

app.get('/api/system/health', (_req, res) => res.json({ status: 'ok', service: 'MediRescue API', mode: 'demo', timestamp: new Date().toISOString() }));
app.get('/api/requests', (req, res) => {
  const { city, status } = req.query;
  res.json(requests.filter(r => (!city || city === 'All Cities' || r.city === city) && (!status || r.status === status)));
});
app.post('/api/requests', (req, res) => {
  const { patient, type, severity, city, address } = req.body || {};
  if (!patient || !type || !severity || !city || !address) return error(res, 400, 'patient, type, severity, city and address are required');
  const request = { id: `ER-${Date.now().toString().slice(-7)}`, patient, type, severity, city, address, status: 'Pending', ambulance: 'Not assigned', createdAt: new Date().toISOString() };
  requests.unshift(request);
  event('emergency.request.created', request);
  res.status(201).json(request);
});
app.get('/api/requests/:id', (req, res) => {
  const item = requests.find(r => r.id === req.params.id);
  return item ? res.json(item) : error(res, 404, 'Emergency request not found');
});
app.get('/api/requests/:id/status', (req, res) => {
  const item = requests.find(r => r.id === req.params.id);
  return item ? res.json({ id: item.id, status: item.status }) : error(res, 404, 'Emergency request not found');
});
app.patch('/api/requests/:id/status', (req, res) => {
  const item = requests.find(r => r.id === req.params.id);
  if (!item) return error(res, 404, 'Emergency request not found');
  const allowed = ['Pending', 'Searching', 'Assigned', 'En Route', 'Arrived', 'Completed', 'Cancelled'];
  if (!allowed.includes(req.body?.status)) return error(res, 400, `status must be one of: ${allowed.join(', ')}`);
  item.status = req.body.status;
  if (['Completed', 'Cancelled'].includes(item.status)) {
    const vehicle = ambulances.find(a => a.assigned === item.id);
    if (vehicle) { vehicle.status = 'Available'; delete vehicle.assigned; }
  }
  event('emergency.status.changed', item);
  res.json(item);
});
app.delete('/api/requests/:id', (req, res) => {
  const item = requests.find(r => r.id === req.params.id);
  if (!item) return error(res, 404, 'Emergency request not found');
  if (['Completed', 'Cancelled'].includes(item.status)) return error(res, 409, 'Request is already closed');
  item.status = 'Cancelled';
  const vehicle = ambulances.find(a => a.assigned === item.id);
  if (vehicle) { vehicle.status = 'Available'; delete vehicle.assigned; }
  event('emergency.request.cancelled', item);
  res.json({ message: 'Request cancelled', request: item });
});
app.get('/api/ambulances', (_req, res) => res.json(ambulances));
app.get('/api/ambulances/:id', (req, res) => {
  const item = ambulances.find(a => a.id === req.params.id);
  return item ? res.json(item) : error(res, 404, 'Ambulance not found');
});
app.get('/api/ambulances/:id/location', (req, res) => {
  const item = ambulances.find(a => a.id === req.params.id);
  return item ? res.json({ id: item.id, lat: item.lat, lng: item.lng, updatedAt: new Date().toISOString() }) : error(res, 404, 'Ambulance not found');
});
app.post('/api/ambulances/:id/assign', (req, res) => {
  const vehicle = ambulances.find(a => a.id === req.params.id);
  const request = requests.find(r => r.id === req.body?.requestId);
  if (!vehicle) return error(res, 404, 'Ambulance not found');
  if (!request) return error(res, 404, 'Emergency request not found');
  if (vehicle.status !== 'Available') return error(res, 409, 'Ambulance is not available');
  if (['Completed', 'Cancelled'].includes(request.status)) return error(res, 409, 'Request is closed');
  vehicle.status = 'Assigned'; vehicle.assigned = request.id;
  request.status = 'Assigned'; request.ambulance = vehicle.id;
  event('ambulance.assigned', { ambulance: vehicle, request });
  res.json({ message: 'Ambulance assigned', ambulance: vehicle, request });
});
app.get('/api/hospitals', (req, res) => {
  const { city } = req.query;
  res.json(hospitals.filter(h => !city || city === 'All Cities' || h.city === city));
});
app.get('/api/events', (_req, res) => res.json(eventLog.slice(0, 50)));
app.post('/api/events', (req, res) => {
  if (!req.body?.type) return error(res, 400, 'type is required');
  res.status(201).json(event(req.body.type, req.body.payload || {}));
});
app.use((_req, res) => error(res, 404, 'Route not found'));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: { message: 'Internal server error', status: 500 } });
});
io.on('connection', socket => {
  socket.emit('medirescue:connected', { message: 'Connected to MediRescue demo events' });
});
const port = Number(process.env.PORT || 4000);
httpServer.listen(port, () => console.log(`MediRescue API running at http://localhost:${port}`));
