# MediRescue — Emergency Ambulance Dispatch Platform

A React + Vite + TypeScript project for the Round 3 High-Level System Design Challenge. The app provides a working local demo of an emergency dispatch dashboard, request management, fleet, hospital directory, architecture explorer, event simulator, caching simulator, and scalability monitor.

## Requirements

- Node.js 20 or later (Node.js 18.18+ may also work)
- npm

## Quick start

1. Extract the ZIP.
2. Open a terminal inside the extracted `MediRescue` folder.
3. Install packages:

   ```bash
   npm install
   npm --prefix server install
   ```

4. Start the frontend and backend together:

   ```bash
   npm run dev
   ```

5. Open:
   - Frontend: http://localhost:5173
   - Backend health check: http://localhost:4000/api/system/health

If the API is not running, the frontend remains usable in demo mode with local sample data.

## Build frontend

```bash
npm run build
```

## Main demo flow

1. Create a new emergency using **New emergency**.
2. Open **Emergency Requests** and assign an available ambulance.
3. Open **Live Tracking** and select an ambulance.
4. Open **Hospitals** and inspect demo hospital information.
5. Open **System Architecture** and click each component.
6. Open **Messaging & Alerts** and publish a sample event.
7. Open **Scalability Monitor** to simulate a traffic spike and demonstrate cache hits/misses.

## Features

- Overview statistics, charts, recent requests, and city summaries
- Emergency request creation, search, filtering, status changes, assignment, and cancellation
- Ambulance fleet management
- Simulated map-style ambulance tracking (positions are demo data, not real vehicle locations)
- Hospital directory with clearly labelled sample capacity data
- Interactive architecture diagram covering API Gateway, backend services, PostgreSQL, Redis, and RabbitMQ
- Event and notification simulator
- Cache hit/miss simulator
- Traffic spike simulator and scalability explanations
- Express.js REST API with validation, status codes, and event broadcasting over Socket.IO
- PostgreSQL schema and index examples

## REST API examples

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/system/health` | Health check |
| GET | `/api/requests` | List requests |
| POST | `/api/requests` | Create request |
| GET | `/api/requests/:id` | Request details |
| GET | `/api/requests/:id/status` | Request status |
| PATCH | `/api/requests/:id/status` | Change status |
| DELETE | `/api/requests/:id` | Cancel request |
| GET | `/api/ambulances` | List fleet |
| GET | `/api/ambulances/:id/location` | Latest demo location |
| POST | `/api/ambulances/:id/assign` | Assign vehicle |
| GET | `/api/hospitals` | List hospitals |
| GET | `/api/events` | Recent emitted events |
| POST | `/api/events` | Emit a demo event |

Example request:

```bash
curl -X POST http://localhost:4000/api/requests \
  -H "Content-Type: application/json" \
  -d '{"patient":"Test Patient","type":"Accident","severity":"Critical","city":"Chennai","address":"Anna Salai"}'
```

## Architecture notes

The supplied server is a self-contained demo backend with in-memory seed data, so it starts without external infrastructure. `database/schema.sql` is a PostgreSQL starter schema. Redis caching and RabbitMQ are represented with a functional frontend demo simulator and documented architecture; configure actual services before describing them as deployed integrations.

For production use, implement real authentication and role-based access control, persistent database repositories, Redis geospatial lookup, RabbitMQ publishers/consumers, Socket.IO authorization, TLS, secret management, monitoring, audit retention, and formal load tests. Demo metrics are illustrative, not real capacity benchmarks.

## Troubleshooting

- If port 5173 is busy, stop the other Vite process or change the port in `vite.config.ts`.
- If port 4000 is busy, set `PORT=4001` in `server/.env` and update `VITE_API_URL` in `.env`.
- If the dashboard shows **Demo mode**, that is expected when the backend is not running; frontend demo actions still work.
